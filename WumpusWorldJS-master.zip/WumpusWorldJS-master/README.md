# WumpusWorld
WumpusWorld simple AI game written in JS

It was a project for AI class.


TODO
 * Clean up dirty code
